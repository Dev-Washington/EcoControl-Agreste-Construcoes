import os
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
import sys

# Carregar variáveis de ambiente
load_dotenv()

# Adicionar o diretório atual ao path
sys.path.insert(0, str(Path(__file__).parent))

from config.database import db
from middleware.error_handler import (
    validation_exception_handler,
    http_exception_handler,
    general_exception_handler
)
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

# Importar rotas
from routes import auth, users, vehicles, customers, deliveries, routes as routes_module
from routes import cities, products, maintenance, messages, access_requests, notifications, reports

# Criar aplicação FastAPI
app = FastAPI(
    title="EcoControl API",
    description="API para o sistema EcoControl - Gestão de Frotas",
    version="1.0.0"
)

# Configurar CORS
cors_origins = os.getenv('CORS_ORIGIN', '*').split(',') if os.getenv('CORS_ORIGIN') else ['*']

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Criar diretórios necessários
dirs = ['./database', './uploads', './uploads/images', './uploads/documents']
for dir_path in dirs:
    Path(dir_path).mkdir(parents=True, exist_ok=True)

# Servir arquivos estáticos (uploads)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Registrar rotas
app.include_router(auth.router, prefix="/api")
app.include_router(users.router, prefix="/api")
app.include_router(vehicles.router, prefix="/api")
app.include_router(customers.router, prefix="/api")
app.include_router(deliveries.router, prefix="/api")
app.include_router(routes_module.router, prefix="/api")
app.include_router(cities.router, prefix="/api")
app.include_router(products.router, prefix="/api")
app.include_router(maintenance.router, prefix="/api")
app.include_router(messages.router, prefix="/api")
app.include_router(access_requests.router, prefix="/api")
app.include_router(notifications.router, prefix="/api")
app.include_router(reports.router, prefix="/api")

# Rota de health check
@app.get("/api/health")
async def health_check():
    from datetime import datetime
    return {
        "status": "ok",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0"
    }

# Handlers de erro
app.add_exception_handler(RequestValidationError, validation_exception_handler)
app.add_exception_handler(StarletteHTTPException, http_exception_handler)
app.add_exception_handler(Exception, general_exception_handler)

# Rota 404
@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return JSONResponse(
        status_code=404,
        content={
            "success": False,
            "message": "Rota não encontrada"
        }
    )

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv('PORT', 3000))
    env = os.getenv('NODE_ENV', 'development')
    
    print(f"🚀 Servidor rodando na porta {port}")
    print(f"📡 Ambiente: {env}")
    print(f"🔗 API disponível em http://localhost:{port}/api")
    print(f"📚 Documentação disponível em http://localhost:{port}/docs")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=port,
        reload=(env == 'development')
    )

