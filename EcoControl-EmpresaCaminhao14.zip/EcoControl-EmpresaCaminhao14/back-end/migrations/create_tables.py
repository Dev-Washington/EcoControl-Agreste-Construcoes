import os
import sys
from pathlib import Path

# Adicionar o diretório raiz ao path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.database import db

def up():
    """Criar todas as tabelas"""
    # Tabela de usuários/funcionários
    db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'funcionario',
            phone TEXT,
            cpf TEXT,
            birth_date TEXT,
            hire_date TEXT,
            address TEXT,
            address_street TEXT,
            address_number TEXT,
            address_complement TEXT,
            address_neighborhood TEXT,
            address_zip_code TEXT,
            address_city TEXT,
            address_state TEXT,
            photo TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            work_schedule TEXT,
            current_truck_id TEXT,
            current_route_id TEXT,
            system_type TEXT DEFAULT 'dashboard',
            company TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (current_truck_id) REFERENCES vehicles(id),
            FOREIGN KEY (current_route_id) REFERENCES routes(id)
        )
    """)
    
    # Tabela de caminhões/veículos
    db.execute("""
        CREATE TABLE IF NOT EXISTS vehicles (
            id TEXT PRIMARY KEY,
            plate TEXT NOT NULL UNIQUE,
            model TEXT NOT NULL,
            year INTEGER,
            capacity INTEGER,
            mileage REAL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'disponivel',
            cargo_description TEXT,
            image TEXT,
            driver_id TEXT,
            route_id TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (driver_id) REFERENCES users(id),
            FOREIGN KEY (route_id) REFERENCES routes(id)
        )
    """)
    
    # Tabela de clientes
    db.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            name_fantasy TEXT,
            document TEXT NOT NULL UNIQUE,
            state_registration TEXT,
            type TEXT NOT NULL DEFAULT 'pf',
            birth_date TEXT,
            email TEXT NOT NULL,
            phone TEXT,
            cellphone TEXT,
            contact_person TEXT,
            address_street TEXT NOT NULL,
            address_number TEXT,
            address_complement TEXT,
            address_neighborhood TEXT NOT NULL,
            address_zip_code TEXT NOT NULL,
            address_city TEXT NOT NULL,
            address_state TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'ativo',
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Tabela de cidades
    db.execute("""
        CREATE TABLE IF NOT EXISTS cities (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            state TEXT NOT NULL,
            zip_code TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(name, state)
        )
    """)
    
    # Tabela de produtos
    db.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            unit TEXT NOT NULL DEFAULT 'kg',
            price REAL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'ativo',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Tabela de rotas
    db.execute("""
        CREATE TABLE IF NOT EXISTS routes (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            origin_street TEXT,
            origin_number TEXT,
            origin_complement TEXT,
            origin_neighborhood TEXT,
            origin_zip_code TEXT,
            origin_city TEXT NOT NULL,
            origin_state TEXT NOT NULL,
            destination_street TEXT,
            destination_number TEXT,
            destination_complement TEXT,
            destination_neighborhood TEXT,
            destination_zip_code TEXT,
            destination_city TEXT NOT NULL,
            destination_state TEXT NOT NULL,
            distance REAL,
            estimated_time INTEGER,
            status TEXT NOT NULL DEFAULT 'ativa',
            assigned_drivers TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Tabela de entregas
    db.execute("""
        CREATE TABLE IF NOT EXISTS deliveries (
            id TEXT PRIMARY KEY,
            tracking_code TEXT UNIQUE NOT NULL,
            customer_id TEXT NOT NULL,
            customer_name TEXT NOT NULL,
            vehicle_id TEXT,
            driver_id TEXT,
            route_id TEXT,
            origin_city TEXT NOT NULL,
            origin_state TEXT NOT NULL,
            destination_city TEXT NOT NULL,
            destination_state TEXT NOT NULL,
            destination_address TEXT,
            scheduled_date TEXT,
            delivery_date TEXT,
            status TEXT NOT NULL DEFAULT 'em_carregamento',
            total_value REAL DEFAULT 0,
            final_value REAL DEFAULT 0,
            payment_method TEXT,
            payment_status TEXT DEFAULT 'pendente',
            notes TEXT,
            items TEXT,
            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(id),
            FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
            FOREIGN KEY (driver_id) REFERENCES users(id),
            FOREIGN KEY (route_id) REFERENCES routes(id)
        )
    """)
    
    # Tabela de manutenções
    db.execute("""
        CREATE TABLE IF NOT EXISTS maintenance (
            id TEXT PRIMARY KEY,
            vehicle_id TEXT NOT NULL,
            type TEXT NOT NULL DEFAULT 'preventiva',
            priority TEXT NOT NULL DEFAULT 'normal',
            description TEXT NOT NULL,
            date TEXT NOT NULL,
            cost REAL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'pendente',
            requested_by TEXT,
            automatic INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
            FOREIGN KEY (requested_by) REFERENCES users(id)
        )
    """)
    
    # Tabela de mensagens/chat
    db.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id TEXT PRIMARY KEY,
            from_user_id TEXT NOT NULL,
            from_user_name TEXT NOT NULL,
            to_user_id TEXT,
            to_user_name TEXT,
            subject TEXT,
            content TEXT,
            image TEXT,
            priority TEXT DEFAULT 'normal',
            read INTEGER DEFAULT 0,
            delivery_id TEXT,
            vehicle_id TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (from_user_id) REFERENCES users(id),
            FOREIGN KEY (to_user_id) REFERENCES users(id),
            FOREIGN KEY (delivery_id) REFERENCES deliveries(id),
            FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
        )
    """)
    
    # Tabela de solicitações de acesso
    db.execute("""
        CREATE TABLE IF NOT EXISTS access_requests (
            id TEXT PRIMARY KEY,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT,
            password TEXT,
            desired_role TEXT NOT NULL,
            system_type TEXT NOT NULL DEFAULT 'dashboard',
            reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            requested_by TEXT,
            reviewed_by TEXT,
            reviewed_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Tabela de notificações
    db.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            type TEXT NOT NULL DEFAULT 'info',
            read INTEGER DEFAULT 0,
            link TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Tabela de logs de chat
    db.execute("""
        CREATE TABLE IF NOT EXISTS chat_logs (
            id TEXT PRIMARY KEY,
            event_type TEXT NOT NULL,
            from_user_id TEXT,
            from_user_name TEXT,
            to_user_id TEXT,
            to_user_name TEXT,
            message_id TEXT,
            conversation_id TEXT,
            duration INTEGER,
            metadata TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (from_user_id) REFERENCES users(id),
            FOREIGN KEY (to_user_id) REFERENCES users(id)
        )
    """)
    
    # Índices para melhor performance
    db.execute("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_vehicles_status ON vehicles(status)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_deliveries_status ON deliveries(status)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_deliveries_customer ON deliveries(customer_id)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_messages_from ON messages(from_user_id)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_messages_to ON messages(to_user_id)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read)")
    
    db.commit()
    print('✅ Tabelas criadas com sucesso')

if __name__ == '__main__':
    up()

