import os
import sys
from pathlib import Path
from datetime import datetime

# Adicionar o diretório raiz ao path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.database import db
from models.user import User
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def seed():
    """Criar dados iniciais"""
    try:
        print('🌱 Iniciando seed do banco de dados...')
        
        # Criar usuário desenvolvedor padrão
        hashed_password = pwd_context.hash('admin123')
        developer_id = '1'
        
        cursor = db.execute('SELECT id FROM users WHERE id = ?', (developer_id,))
        existing_dev = cursor.fetchone()
        
        if not existing_dev:
            now = datetime.now().isoformat()
            db.execute("""
                INSERT INTO users (
                    id, name, email, password, role, phone, company, status, system_type, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                developer_id,
                'Desenvolvedor',
                'desenvolvedor@control.com',
                hashed_password,
                'gestor',
                '(11) 99999-9999',
                'Agreste Construção',
                'active',
                'dashboard',
                now
            ))
            db.commit()
            print('✅ Usuário desenvolvedor criado')
        else:
            print('ℹ️  Usuário desenvolvedor já existe')
        
        print('✅ Seed concluído com sucesso!')
    except Exception as error:
        print(f'❌ Erro ao executar seed: {error}')
        raise

if __name__ == '__main__':
    seed()

