from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel, EmailStr
from passlib.context import CryptContext
from models.user import User
from middleware.auth import generate_token, get_current_user

router = APIRouter(prefix="/auth", tags=["auth"])
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class LoginResponse(BaseModel):
    success: bool
    message: str
    data: dict

@router.post("/login", response_model=LoginResponse)
async def login(login_data: LoginRequest):
    """Endpoint de login"""
    try:
        user = User.find_by_email(login_data.email)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Email ou senha incorretos"
            )
        
        if not pwd_context.verify(login_data.password, user['password']):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Email ou senha incorretos"
            )
        
        if user['status'] != 'active':
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Usuário inativo"
            )
        
        token = generate_token(user['id'])
        
        # Remover senha da resposta
        user_dict = {k: v for k, v in user.items() if k != 'password'}
        
        return {
            "success": True,
            "message": "Login realizado com sucesso",
            "data": {
                "user": user_dict,
                "token": token
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro no login: {e}')
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao realizar login"
        )

@router.get("/verify")
async def verify_token(current_user: dict = Depends(get_current_user)):
    """Verificar token"""
    user_dict = {k: v for k, v in current_user.items() if k != 'password'}
    return {
        "success": True,
        "data": {
            "user": user_dict
        }
    }

