from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel
from models.route import Route
from middleware.auth import get_current_user

router = APIRouter(prefix="/routes", tags=["routes"])

class RouteCreate(BaseModel):
    name: str
    originCity: str
    originState: str
    destinationCity: str
    destinationState: str
    originStreet: str = None
    originNumber: str = None
    originComplement: str = None
    originNeighborhood: str = None
    originZipCode: str = None
    destinationStreet: str = None
    destinationNumber: str = None
    destinationComplement: str = None
    destinationNeighborhood: str = None
    destinationZipCode: str = None
    distance: float = None
    estimatedTime: int = None
    status: str = "ativa"
    assignedDrivers: list = None

class RouteUpdate(BaseModel):
    name: str = None
    originCity: str = None
    originState: str = None
    destinationCity: str = None
    destinationState: str = None
    originStreet: str = None
    originNumber: str = None
    originComplement: str = None
    originNeighborhood: str = None
    originZipCode: str = None
    destinationStreet: str = None
    destinationNumber: str = None
    destinationComplement: str = None
    destinationNeighborhood: str = None
    destinationZipCode: str = None
    distance: float = None
    estimatedTime: int = None
    status: str = None
    assignedDrivers: list = None

@router.get("")
async def list_routes(
    status: str = Query(None),
    search: str = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """Listar rotas"""
    try:
        filters = {}
        if status:
            filters['status'] = status
        if search:
            filters['search'] = search
        
        routes = Route.find_all(filters)
        return {"success": True, "data": {"routes": routes}}
    except Exception as e:
        print(f'Erro ao listar rotas: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar rotas")

@router.get("/{route_id}")
async def get_route(route_id: str, current_user: dict = Depends(get_current_user)):
    """Obter rota por ID"""
    try:
        route = Route.find_by_id(route_id)
        if not route:
            raise HTTPException(status_code=404, detail="Rota não encontrada")
        return {"success": True, "data": {"route": route}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao obter rota: {e}')
        raise HTTPException(status_code=500, detail="Erro ao obter rota")

@router.post("")
async def create_route(route_data: RouteCreate, current_user: dict = Depends(get_current_user)):
    """Criar rota"""
    try:
        route_dict = route_data.dict()
        route = Route.create(route_dict)
        return {"success": True, "message": "Rota criada com sucesso", "data": {"route": route}}
    except Exception as e:
        print(f'Erro ao criar rota: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar rota")

@router.put("/{route_id}")
async def update_route(
    route_id: str,
    route_data: RouteUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Atualizar rota"""
    try:
        route = Route.find_by_id(route_id)
        if not route:
            raise HTTPException(status_code=404, detail="Rota não encontrada")
        
        update_data = route_data.dict(exclude_unset=True)
        updated_route = Route.update(route_id, update_data)
        return {"success": True, "message": "Rota atualizada com sucesso", "data": {"route": updated_route}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao atualizar rota: {e}')
        raise HTTPException(status_code=500, detail="Erro ao atualizar rota")

@router.delete("/{route_id}")
async def delete_route(route_id: str, current_user: dict = Depends(get_current_user)):
    """Deletar rota"""
    try:
        route = Route.find_by_id(route_id)
        if not route:
            raise HTTPException(status_code=404, detail="Rota não encontrada")
        
        Route.delete(route_id)
        return {"success": True, "message": "Rota deletada com sucesso"}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao deletar rota: {e}')
        raise HTTPException(status_code=500, detail="Erro ao deletar rota")

