from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel
from models.delivery import Delivery
from middleware.auth import get_current_user

router = APIRouter(prefix="/deliveries", tags=["deliveries"])

class DeliveryCreate(BaseModel):
    customerId: str
    customerName: str
    originCity: str
    originState: str
    destinationCity: str
    destinationState: str
    vehicleId: str = None
    driverId: str = None
    routeId: str = None
    destinationAddress: str = None
    scheduledDate: str = None
    deliveryDate: str = None
    status: str = "em_carregamento"
    totalValue: float = 0
    finalValue: float = 0
    paymentMethod: str = None
    paymentStatus: str = "pendente"
    notes: str = None
    items: list = None
    createdBy: str = None

class DeliveryUpdate(BaseModel):
    customerId: str = None
    customerName: str = None
    originCity: str = None
    originState: str = None
    destinationCity: str = None
    destinationState: str = None
    vehicleId: str = None
    driverId: str = None
    routeId: str = None
    destinationAddress: str = None
    scheduledDate: str = None
    deliveryDate: str = None
    status: str = None
    totalValue: float = None
    finalValue: float = None
    paymentMethod: str = None
    paymentStatus: str = None
    notes: str = None
    items: list = None

@router.get("")
async def list_deliveries(
    status: str = Query(None),
    customerId: str = Query(None),
    driverId: str = Query(None),
    search: str = Query(None),
    dateStart: str = Query(None),
    dateEnd: str = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """Listar entregas"""
    try:
        filters = {}
        if status:
            filters['status'] = status
        if customerId:
            filters['customerId'] = customerId
        if driverId:
            filters['driverId'] = driverId
        if search:
            filters['search'] = search
        if dateStart:
            filters['dateStart'] = dateStart
        if dateEnd:
            filters['dateEnd'] = dateEnd
        
        deliveries = Delivery.find_all(filters)
        return {"success": True, "data": {"deliveries": deliveries}}
    except Exception as e:
        print(f'Erro ao listar entregas: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar entregas")

@router.get("/{delivery_id}")
async def get_delivery(delivery_id: str, current_user: dict = Depends(get_current_user)):
    """Obter entrega por ID"""
    try:
        delivery = Delivery.find_by_id(delivery_id)
        if not delivery:
            raise HTTPException(status_code=404, detail="Entrega não encontrada")
        return {"success": True, "data": {"delivery": delivery}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao obter entrega: {e}')
        raise HTTPException(status_code=500, detail="Erro ao obter entrega")

@router.post("")
async def create_delivery(delivery_data: DeliveryCreate, current_user: dict = Depends(get_current_user)):
    """Criar entrega"""
    try:
        delivery_dict = delivery_data.dict()
        if not delivery_dict.get('createdBy'):
            delivery_dict['createdBy'] = current_user['id']
        delivery = Delivery.create(delivery_dict)
        return {"success": True, "message": "Entrega criada com sucesso", "data": {"delivery": delivery}}
    except Exception as e:
        print(f'Erro ao criar entrega: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar entrega")

@router.put("/{delivery_id}")
async def update_delivery(
    delivery_id: str,
    delivery_data: DeliveryUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Atualizar entrega"""
    try:
        delivery = Delivery.find_by_id(delivery_id)
        if not delivery:
            raise HTTPException(status_code=404, detail="Entrega não encontrada")
        
        update_data = delivery_data.dict(exclude_unset=True)
        updated_delivery = Delivery.update(delivery_id, update_data)
        return {"success": True, "message": "Entrega atualizada com sucesso", "data": {"delivery": updated_delivery}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao atualizar entrega: {e}')
        raise HTTPException(status_code=500, detail="Erro ao atualizar entrega")

@router.delete("/{delivery_id}")
async def delete_delivery(delivery_id: str, current_user: dict = Depends(get_current_user)):
    """Deletar entrega"""
    try:
        delivery = Delivery.find_by_id(delivery_id)
        if not delivery:
            raise HTTPException(status_code=404, detail="Entrega não encontrada")
        
        Delivery.delete(delivery_id)
        return {"success": True, "message": "Entrega deletada com sucesso"}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao deletar entrega: {e}')
        raise HTTPException(status_code=500, detail="Erro ao deletar entrega")

