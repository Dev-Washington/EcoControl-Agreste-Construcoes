from fastapi import APIRouter, HTTPException, Depends
from config.database import db
from middleware.auth import get_current_user

router = APIRouter(prefix="/reports", tags=["reports"])

@router.get("/dashboard")
async def get_dashboard_report(current_user: dict = Depends(get_current_user)):
    """Relatório do dashboard"""
    try:
        # Estatísticas básicas
        vehicles_cursor = db.execute('SELECT COUNT(*) as total FROM vehicles')
        vehicles_total = vehicles_cursor.fetchone()['total']
        
        vehicles_available_cursor = db.execute("SELECT COUNT(*) as total FROM vehicles WHERE status = 'disponivel'")
        vehicles_available = vehicles_available_cursor.fetchone()['total']
        
        deliveries_cursor = db.execute('SELECT COUNT(*) as total FROM deliveries')
        deliveries_total = deliveries_cursor.fetchone()['total']
        
        deliveries_pending_cursor = db.execute("SELECT COUNT(*) as total FROM deliveries WHERE status = 'em_carregamento'")
        deliveries_pending = deliveries_pending_cursor.fetchone()['total']
        
        customers_cursor = db.execute('SELECT COUNT(*) as total FROM customers')
        customers_total = customers_cursor.fetchone()['total']
        
        users_cursor = db.execute('SELECT COUNT(*) as total FROM users')
        users_total = users_cursor.fetchone()['total']
        
        return {
            "success": True,
            "data": {
                "vehicles": {
                    "total": vehicles_total,
                    "available": vehicles_available
                },
                "deliveries": {
                    "total": deliveries_total,
                    "pending": deliveries_pending
                },
                "customers": {
                    "total": customers_total
                },
                "users": {
                    "total": users_total
                }
            }
        }
    except Exception as e:
        print(f'Erro ao gerar relatório: {e}')
        raise HTTPException(status_code=500, detail="Erro ao gerar relatório")

