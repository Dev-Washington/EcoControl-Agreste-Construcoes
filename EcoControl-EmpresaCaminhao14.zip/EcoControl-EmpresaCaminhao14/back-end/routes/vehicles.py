from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel
from models.vehicle import Vehicle
from middleware.auth import get_current_user

router = APIRouter(prefix="/vehicles", tags=["vehicles"])

class VehicleCreate(BaseModel):
    plate: str
    model: str
    year: int = None
    capacity: int = None
    mileage: float = 0
    status: str = "disponivel"
    cargoDescription: str = None
    image: str = None
    driverId: str = None
    routeId: str = None

class VehicleUpdate(BaseModel):
    plate: str = None
    model: str = None
    year: int = None
    capacity: int = None
    mileage: float = None
    status: str = None
    cargoDescription: str = None
    image: str = None
    driverId: str = None
    routeId: str = None

@router.get("")
async def list_vehicles(
    status: str = Query(None),
    search: str = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """Listar veículos"""
    try:
        filters = {}
        if status:
            filters['status'] = status
        if search:
            filters['search'] = search
        
        vehicles = Vehicle.find_all(filters)
        return {"success": True, "data": {"vehicles": vehicles}}
    except Exception as e:
        print(f'Erro ao listar veículos: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar veículos")

@router.get("/{vehicle_id}")
async def get_vehicle(vehicle_id: str, current_user: dict = Depends(get_current_user)):
    """Obter veículo por ID"""
    try:
        vehicle = Vehicle.find_by_id(vehicle_id)
        if not vehicle:
            raise HTTPException(status_code=404, detail="Veículo não encontrado")
        return {"success": True, "data": {"vehicle": vehicle}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao obter veículo: {e}')
        raise HTTPException(status_code=500, detail="Erro ao obter veículo")

@router.post("")
async def create_vehicle(vehicle_data: VehicleCreate, current_user: dict = Depends(get_current_user)):
    """Criar veículo"""
    try:
        vehicle_dict = vehicle_data.dict()
        vehicle = Vehicle.create(vehicle_dict)
        return {"success": True, "message": "Veículo criado com sucesso", "data": {"vehicle": vehicle}}
    except Exception as e:
        print(f'Erro ao criar veículo: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar veículo")

@router.put("/{vehicle_id}")
async def update_vehicle(
    vehicle_id: str,
    vehicle_data: VehicleUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Atualizar veículo"""
    try:
        vehicle = Vehicle.find_by_id(vehicle_id)
        if not vehicle:
            raise HTTPException(status_code=404, detail="Veículo não encontrado")
        
        update_data = vehicle_data.dict(exclude_unset=True)
        updated_vehicle = Vehicle.update(vehicle_id, update_data)
        return {"success": True, "message": "Veículo atualizado com sucesso", "data": {"vehicle": updated_vehicle}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao atualizar veículo: {e}')
        raise HTTPException(status_code=500, detail="Erro ao atualizar veículo")

@router.delete("/{vehicle_id}")
async def delete_vehicle(vehicle_id: str, current_user: dict = Depends(get_current_user)):
    """Deletar veículo"""
    try:
        vehicle = Vehicle.find_by_id(vehicle_id)
        if not vehicle:
            raise HTTPException(status_code=404, detail="Veículo não encontrado")
        
        Vehicle.delete(vehicle_id)
        return {"success": True, "message": "Veículo deletado com sucesso"}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao deletar veículo: {e}')
        raise HTTPException(status_code=500, detail="Erro ao deletar veículo")

