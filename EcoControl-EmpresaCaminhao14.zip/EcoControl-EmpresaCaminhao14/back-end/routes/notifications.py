from fastapi import APIRouter, HTTPException, Depends
from config.database import db
from middleware.auth import get_current_user
import uuid
from datetime import datetime

router = APIRouter(prefix="/notifications", tags=["notifications"])

@router.get("")
async def list_notifications(current_user: dict = Depends(get_current_user)):
    """Listar notificações do usuário"""
    try:
        cursor = db.execute(
            'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC',
            (current_user['id'],)
        )
        rows = cursor.fetchall()
        notifications = [dict(row) for row in rows]
        return {"success": True, "data": {"notifications": notifications}}
    except Exception as e:
        print(f'Erro ao listar notificações: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar notificações")

@router.put("/{notification_id}/read")
async def mark_notification_as_read(notification_id: str, current_user: dict = Depends(get_current_user)):
    """Marcar notificação como lida"""
    try:
        db.execute(
            'UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?',
            (notification_id, current_user['id'])
        )
        db.commit()
        
        cursor = db.execute('SELECT * FROM notifications WHERE id = ?', (notification_id,))
        notification = dict(cursor.fetchone())
        
        return {"success": True, "message": "Notificação marcada como lida", "data": {"notification": notification}}
    except Exception as e:
        print(f'Erro ao marcar notificação: {e}')
        raise HTTPException(status_code=500, detail="Erro ao marcar notificação")

