from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel
from models.maintenance import Maintenance
from middleware.auth import get_current_user

router = APIRouter(prefix="/maintenance", tags=["maintenance"])

class MaintenanceCreate(BaseModel):
    vehicleId: str
    type: str = "preventiva"
    priority: str = "normal"
    description: str
    date: str
    cost: float = 0
    status: str = "pendente"
    requestedBy: str = None
    automatic: bool = False

class MaintenanceUpdate(BaseModel):
    vehicleId: str = None
    type: str = None
    priority: str = None
    description: str = None
    date: str = None
    cost: float = None
    status: str = None

@router.get("")
async def list_maintenance(
    vehicleId: str = Query(None),
    status: str = Query(None),
    type: str = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """Listar manutenções"""
    try:
        filters = {}
        if vehicleId:
            filters['vehicleId'] = vehicleId
        if status:
            filters['status'] = status
        if type:
            filters['type'] = type
        
        maintenance_list = Maintenance.find_all(filters)
        return {"success": True, "data": {"maintenance": maintenance_list}}
    except Exception as e:
        print(f'Erro ao listar manutenções: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar manutenções")

@router.post("")
async def create_maintenance(maintenance_data: MaintenanceCreate, current_user: dict = Depends(get_current_user)):
    """Criar manutenção"""
    try:
        maintenance_dict = maintenance_data.dict()
        if not maintenance_dict.get('requestedBy'):
            maintenance_dict['requestedBy'] = current_user['id']
        maintenance = Maintenance.create(maintenance_dict)
        return {"success": True, "message": "Manutenção criada com sucesso", "data": {"maintenance": maintenance}}
    except Exception as e:
        print(f'Erro ao criar manutenção: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar manutenção")

@router.put("/{maintenance_id}")
async def update_maintenance(
    maintenance_id: str,
    maintenance_data: MaintenanceUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Atualizar manutenção"""
    try:
        maintenance = Maintenance.find_by_id(maintenance_id)
        if not maintenance:
            raise HTTPException(status_code=404, detail="Manutenção não encontrada")
        
        update_data = maintenance_data.dict(exclude_unset=True)
        updated_maintenance = Maintenance.update(maintenance_id, update_data)
        return {"success": True, "message": "Manutenção atualizada com sucesso", "data": {"maintenance": updated_maintenance}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao atualizar manutenção: {e}')
        raise HTTPException(status_code=500, detail="Erro ao atualizar manutenção")

