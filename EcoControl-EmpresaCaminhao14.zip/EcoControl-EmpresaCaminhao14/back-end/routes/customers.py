from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, EmailStr
from models.customer import Customer
from middleware.auth import get_current_user

router = APIRouter(prefix="/customers", tags=["customers"])

class CustomerCreate(BaseModel):
    name: str
    document: str
    email: EmailStr
    addressStreet: str
    addressNeighborhood: str
    addressZipCode: str
    addressCity: str
    addressState: str
    nameFantasy: str = None
    stateRegistration: str = None
    type: str = "pf"
    birthDate: str = None
    phone: str = None
    cellphone: str = None
    contactPerson: str = None
    addressNumber: str = None
    addressComplement: str = None
    status: str = "ativo"
    notes: str = None

class CustomerUpdate(BaseModel):
    name: str = None
    document: str = None
    email: EmailStr = None
    addressStreet: str = None
    addressNeighborhood: str = None
    addressZipCode: str = None
    addressCity: str = None
    addressState: str = None
    nameFantasy: str = None
    stateRegistration: str = None
    type: str = None
    birthDate: str = None
    phone: str = None
    cellphone: str = None
    contactPerson: str = None
    addressNumber: str = None
    addressComplement: str = None
    status: str = None
    notes: str = None

@router.get("")
async def list_customers(
    status: str = Query(None),
    type: str = Query(None),
    search: str = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """Listar clientes"""
    try:
        filters = {}
        if status:
            filters['status'] = status
        if type:
            filters['type'] = type
        if search:
            filters['search'] = search
        
        customers = Customer.find_all(filters)
        return {"success": True, "data": {"customers": customers}}
    except Exception as e:
        print(f'Erro ao listar clientes: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar clientes")

@router.get("/{customer_id}")
async def get_customer(customer_id: str, current_user: dict = Depends(get_current_user)):
    """Obter cliente por ID"""
    try:
        customer = Customer.find_by_id(customer_id)
        if not customer:
            raise HTTPException(status_code=404, detail="Cliente não encontrado")
        return {"success": True, "data": {"customer": customer}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao obter cliente: {e}')
        raise HTTPException(status_code=500, detail="Erro ao obter cliente")

@router.post("")
async def create_customer(customer_data: CustomerCreate, current_user: dict = Depends(get_current_user)):
    """Criar cliente"""
    try:
        customer_dict = customer_data.dict()
        customer = Customer.create(customer_dict)
        return {"success": True, "message": "Cliente criado com sucesso", "data": {"customer": customer}}
    except Exception as e:
        print(f'Erro ao criar cliente: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar cliente")

@router.put("/{customer_id}")
async def update_customer(
    customer_id: str,
    customer_data: CustomerUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Atualizar cliente"""
    try:
        customer = Customer.find_by_id(customer_id)
        if not customer:
            raise HTTPException(status_code=404, detail="Cliente não encontrado")
        
        update_data = customer_data.dict(exclude_unset=True)
        updated_customer = Customer.update(customer_id, update_data)
        return {"success": True, "message": "Cliente atualizado com sucesso", "data": {"customer": updated_customer}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao atualizar cliente: {e}')
        raise HTTPException(status_code=500, detail="Erro ao atualizar cliente")

@router.delete("/{customer_id}")
async def delete_customer(customer_id: str, current_user: dict = Depends(get_current_user)):
    """Deletar cliente"""
    try:
        customer = Customer.find_by_id(customer_id)
        if not customer:
            raise HTTPException(status_code=404, detail="Cliente não encontrado")
        
        Customer.delete(customer_id)
        return {"success": True, "message": "Cliente deletado com sucesso"}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao deletar cliente: {e}')
        raise HTTPException(status_code=500, detail="Erro ao deletar cliente")

