from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from config.database import db
from middleware.auth import get_current_user
import uuid
from datetime import datetime

router = APIRouter(prefix="/cities", tags=["cities"])

class CityCreate(BaseModel):
    name: str
    state: str
    zipCode: str = None

@router.get("")
async def list_cities(current_user: dict = Depends(get_current_user)):
    """Listar cidades"""
    try:
        cursor = db.execute('SELECT * FROM cities ORDER BY name, state')
        rows = cursor.fetchall()
        cities = [dict(row) for row in rows]
        return {"success": True, "data": {"cities": cities}}
    except Exception as e:
        print(f'Erro ao listar cidades: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar cidades")

@router.post("")
async def create_city(city_data: CityCreate, current_user: dict = Depends(get_current_user)):
    """Criar cidade"""
    try:
        city_id = f"CITY-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        db.execute("""
            INSERT INTO cities (id, name, state, zip_code, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (city_id, city_data.name, city_data.state, city_data.zipCode, now, now))
        db.commit()
        
        cursor = db.execute('SELECT * FROM cities WHERE id = ?', (city_id,))
        city = dict(cursor.fetchone())
        
        return {"success": True, "message": "Cidade criada com sucesso", "data": {"city": city}}
    except Exception as e:
        print(f'Erro ao criar cidade: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar cidade")

