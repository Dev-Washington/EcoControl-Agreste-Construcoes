from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, EmailStr
from models.access_request import AccessRequest
from models.user import User
from passlib.context import CryptContext
from middleware.auth import get_current_user
from datetime import datetime

router = APIRouter(prefix="/access-requests", tags=["access-requests"])
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class AccessRequestCreate(BaseModel):
    fullName: str
    email: EmailStr
    phone: str = None
    password: str = None
    desiredRole: str
    systemType: str = "dashboard"
    reason: str

@router.post("")
async def create_access_request(request_data: AccessRequestCreate):
    """Criar solicitação de acesso (público)"""
    try:
        request_dict = request_data.dict()
        if request_dict.get('password'):
            request_dict['password'] = pwd_context.hash(request_dict['password'])
        access_request = AccessRequest.create(request_dict)
        return {"success": True, "message": "Solicitação criada com sucesso", "data": {"accessRequest": access_request}}
    except Exception as e:
        print(f'Erro ao criar solicitação: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar solicitação")

@router.get("")
async def list_access_requests(
    status: str = Query(None),
    email: str = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """Listar solicitações (apenas gestores)"""
    if current_user['role'] not in ['gestor', 'desenvolvedor']:
        raise HTTPException(status_code=403, detail="Acesso negado")
    
    try:
        filters = {}
        if status:
            filters['status'] = status
        if email:
            filters['email'] = email
        
        requests = AccessRequest.find_all(filters)
        return {"success": True, "data": {"accessRequests": requests}}
    except Exception as e:
        print(f'Erro ao listar solicitações: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar solicitações")

@router.put("/{request_id}/approve")
async def approve_access_request(request_id: str, current_user: dict = Depends(get_current_user)):
    """Aprovar solicitação"""
    if current_user['role'] not in ['gestor', 'desenvolvedor']:
        raise HTTPException(status_code=403, detail="Acesso negado")
    
    try:
        access_request = AccessRequest.find_by_id(request_id)
        if not access_request:
            raise HTTPException(status_code=404, detail="Solicitação não encontrada")
        
        # Criar usuário a partir da solicitação
        user_data = {
            'name': access_request['full_name'],
            'email': access_request['email'],
            'password': access_request.get('password') or pwd_context.hash('senha123'),
            'role': access_request['desired_role'],
            'phone': access_request.get('phone'),
            'systemType': access_request.get('system_type', 'dashboard')
        }
        
        User.create(user_data)
        
        # Atualizar solicitação
        AccessRequest.update(request_id, {
            'status': 'approved',
            'reviewedBy': current_user['id'],
            'reviewedAt': datetime.now().isoformat()
        })
        
        return {"success": True, "message": "Solicitação aprovada e usuário criado com sucesso"}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao aprovar solicitação: {e}')
        raise HTTPException(status_code=500, detail="Erro ao aprovar solicitação")

@router.put("/{request_id}/reject")
async def reject_access_request(request_id: str, current_user: dict = Depends(get_current_user)):
    """Rejeitar solicitação"""
    if current_user['role'] not in ['gestor', 'desenvolvedor']:
        raise HTTPException(status_code=403, detail="Acesso negado")
    
    try:
        access_request = AccessRequest.find_by_id(request_id)
        if not access_request:
            raise HTTPException(status_code=404, detail="Solicitação não encontrada")
        
        AccessRequest.update(request_id, {
            'status': 'rejected',
            'reviewedBy': current_user['id'],
            'reviewedAt': datetime.now().isoformat()
        })
        
        return {"success": True, "message": "Solicitação rejeitada com sucesso"}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao rejeitar solicitação: {e}')
        raise HTTPException(status_code=500, detail="Erro ao rejeitar solicitação")

