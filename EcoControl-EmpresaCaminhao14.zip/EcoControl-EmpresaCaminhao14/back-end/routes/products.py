from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from config.database import db
from middleware.auth import get_current_user
import uuid
from datetime import datetime

router = APIRouter(prefix="/products", tags=["products"])

class ProductCreate(BaseModel):
    name: str
    description: str = None
    unit: str = "kg"
    price: float = 0
    status: str = "ativo"

@router.get("")
async def list_products(current_user: dict = Depends(get_current_user)):
    """Listar produtos"""
    try:
        cursor = db.execute('SELECT * FROM products ORDER BY name')
        rows = cursor.fetchall()
        products = [dict(row) for row in rows]
        return {"success": True, "data": {"products": products}}
    except Exception as e:
        print(f'Erro ao listar produtos: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar produtos")

@router.post("")
async def create_product(product_data: ProductCreate, current_user: dict = Depends(get_current_user)):
    """Criar produto"""
    try:
        product_id = f"PROD-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        db.execute("""
            INSERT INTO products (id, name, description, unit, price, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (product_id, product_data.name, product_data.description, product_data.unit, 
              product_data.price, product_data.status, now, now))
        db.commit()
        
        cursor = db.execute('SELECT * FROM products WHERE id = ?', (product_id,))
        product = dict(cursor.fetchone())
        
        return {"success": True, "message": "Produto criado com sucesso", "data": {"product": product}}
    except Exception as e:
        print(f'Erro ao criar produto: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar produto")

