from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from models.message import Message
from middleware.auth import get_current_user

router = APIRouter(prefix="/messages", tags=["messages"])

class MessageCreate(BaseModel):
    fromUserId: str
    fromUserName: str
    toUserId: str = None
    toUserName: str = None
    subject: str = None
    content: str = None
    image: str = None
    priority: str = "normal"
    read: bool = False
    deliveryId: str = None
    vehicleId: str = None

@router.get("/conversation/{user_id}")
async def get_conversation(user_id: str, current_user: dict = Depends(get_current_user)):
    """Obter conversa entre dois usuários"""
    try:
        messages = Message.find_conversation(current_user['id'], user_id)
        return {"success": True, "data": {"messages": messages}}
    except Exception as e:
        print(f'Erro ao obter conversa: {e}')
        raise HTTPException(status_code=500, detail="Erro ao obter conversa")

@router.get("/my-messages")
async def get_my_messages(current_user: dict = Depends(get_current_user)):
    """Obter minhas mensagens"""
    try:
        messages = Message.find_user_messages(current_user['id'])
        return {"success": True, "data": {"messages": messages}}
    except Exception as e:
        print(f'Erro ao obter mensagens: {e}')
        raise HTTPException(status_code=500, detail="Erro ao obter mensagens")

@router.post("")
async def create_message(message_data: MessageCreate, current_user: dict = Depends(get_current_user)):
    """Enviar mensagem"""
    try:
        message_dict = message_data.dict()
        if message_dict.get('fromUserId') != current_user['id']:
            message_dict['fromUserId'] = current_user['id']
            message_dict['fromUserName'] = current_user['name']
        message = Message.create(message_dict)
        return {"success": True, "message": "Mensagem enviada com sucesso", "data": {"message": message}}
    except Exception as e:
        print(f'Erro ao enviar mensagem: {e}')
        raise HTTPException(status_code=500, detail="Erro ao enviar mensagem")

@router.put("/{message_id}/read")
async def mark_message_as_read(message_id: str, current_user: dict = Depends(get_current_user)):
    """Marcar mensagem como lida"""
    try:
        message = Message.mark_as_read(message_id)
        return {"success": True, "message": "Mensagem marcada como lida", "data": {"message": message}}
    except Exception as e:
        print(f'Erro ao marcar mensagem: {e}')
        raise HTTPException(status_code=500, detail="Erro ao marcar mensagem")

@router.put("/conversation/{user_id}/read")
async def mark_conversation_as_read(user_id: str, current_user: dict = Depends(get_current_user)):
    """Marcar conversa como lida"""
    try:
        Message.mark_conversation_as_read(current_user['id'], user_id)
        return {"success": True, "message": "Conversa marcada como lida"}
    except Exception as e:
        print(f'Erro ao marcar conversa: {e}')
        raise HTTPException(status_code=500, detail="Erro ao marcar conversa")

@router.delete("/conversation/{user_id}")
async def delete_conversation(user_id: str, current_user: dict = Depends(get_current_user)):
    """Deletar conversa"""
    try:
        Message.delete_conversation(current_user['id'], user_id)
        return {"success": True, "message": "Conversa deletada com sucesso"}
    except Exception as e:
        print(f'Erro ao deletar conversa: {e}')
        raise HTTPException(status_code=500, detail="Erro ao deletar conversa")

