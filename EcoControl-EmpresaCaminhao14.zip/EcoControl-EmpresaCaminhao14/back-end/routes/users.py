from fastapi import APIRouter, HTTPException, status, Depends, Query
from pydantic import BaseModel, EmailStr
from passlib.context import CryptContext
from models.user import User
from middleware.auth import get_current_user, authorize

router = APIRouter(prefix="/users", tags=["users"])
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str = "funcionario"
    phone: str = None
    cpf: str = None
    company: str = None

class UserUpdate(BaseModel):
    name: str = None
    email: EmailStr = None
    password: str = None
    role: str = None
    phone: str = None
    cpf: str = None
    status: str = None

@router.get("")
async def list_users(
    role: str = Query(None),
    status_filter: str = Query(None, alias="status"),
    search: str = Query(None),
    current_user: dict = Depends(get_current_user)
):
    """Listar usuários"""
    try:
        filters = {}
        if role:
            filters['role'] = role
        if status_filter:
            filters['status'] = status_filter
        if search:
            filters['search'] = search
        
        users = User.find_all(filters)
        safe_users = [{k: v for k, v in u.items() if k != 'password'} for u in users]
        
        return {"success": True, "data": {"users": safe_users}}
    except Exception as e:
        print(f'Erro ao listar usuários: {e}')
        raise HTTPException(status_code=500, detail="Erro ao listar usuários")

@router.get("/{user_id}")
async def get_user(user_id: str, current_user: dict = Depends(get_current_user)):
    """Obter usuário por ID"""
    try:
        user = User.find_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="Usuário não encontrado")
        
        user_dict = {k: v for k, v in user.items() if k != 'password'}
        return {"success": True, "data": {"user": user_dict}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao obter usuário: {e}')
        raise HTTPException(status_code=500, detail="Erro ao obter usuário")

@router.post("")
async def create_user(
    user_data: UserCreate,
    current_user: dict = Depends(get_current_user)
):
    """Criar usuário (apenas gestores)"""
    if current_user['role'] not in ['gestor', 'desenvolvedor']:
        raise HTTPException(status_code=403, detail="Acesso negado")
    
    try:
        if len(user_data.password) < 6:
            raise HTTPException(status_code=400, detail="Senha deve ter no mínimo 6 caracteres")
        
        existing_user = User.find_by_email(user_data.email)
        if existing_user:
            raise HTTPException(status_code=409, detail="Email já cadastrado")
        
        hashed_password = pwd_context.hash(user_data.password)
        
        user_dict = {
            'name': user_data.name,
            'email': user_data.email,
            'password': hashed_password,
            'role': user_data.role,
            'phone': user_data.phone,
            'cpf': user_data.cpf,
            'company': user_data.company
        }
        
        user = User.create(user_dict)
        user_dict = {k: v for k, v in user.items() if k != 'password'}
        
        return {"success": True, "message": "Usuário criado com sucesso", "data": {"user": user_dict}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao criar usuário: {e}')
        raise HTTPException(status_code=500, detail="Erro ao criar usuário")

@router.put("/{user_id}")
async def update_user(
    user_id: str,
    user_data: UserUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Atualizar usuário"""
    try:
        user = User.find_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="Usuário não encontrado")
        
        # Verificar permissões
        if current_user['role'] not in ['gestor', 'desenvolvedor'] and current_user['id'] != user_id:
            raise HTTPException(status_code=403, detail="Acesso negado")
        
        update_data = user_data.dict(exclude_unset=True)
        
        if 'password' in update_data:
            update_data['password'] = pwd_context.hash(update_data['password'])
        
        # Converter para formato do modelo
        model_data = {}
        for key, value in update_data.items():
            model_data[key] = value
        
        updated_user = User.update(user_id, model_data)
        user_dict = {k: v for k, v in updated_user.items() if k != 'password'}
        
        return {"success": True, "message": "Usuário atualizado com sucesso", "data": {"user": user_dict}}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao atualizar usuário: {e}')
        raise HTTPException(status_code=500, detail="Erro ao atualizar usuário")

@router.delete("/{user_id}")
async def delete_user(
    user_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Deletar usuário (apenas gestores)"""
    if current_user['role'] not in ['gestor', 'desenvolvedor']:
        raise HTTPException(status_code=403, detail="Acesso negado")
    
    try:
        user = User.find_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail="Usuário não encontrado")
        
        User.delete(user_id)
        return {"success": True, "message": "Usuário deletado com sucesso"}
    except HTTPException:
        raise
    except Exception as e:
        print(f'Erro ao deletar usuário: {e}')
        raise HTTPException(status_code=500, detail="Erro ao deletar usuário")

