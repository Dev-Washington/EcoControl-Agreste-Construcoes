from fastapi import Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import os
import traceback

async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Handler para erros de validação"""
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            'success': False,
            'message': 'Erro de validação',
            'errors': exc.errors()
        }
    )

async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    """Handler para exceções HTTP"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            'success': False,
            'message': exc.detail
        }
    )

async def general_exception_handler(request: Request, exc: Exception):
    """Handler para erros gerais"""
    print(f'Erro: {exc}')
    if os.getenv('NODE_ENV') == 'development':
        print(traceback.format_exc())
    
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            'success': False,
            'message': 'Erro interno do servidor',
            **({'stack': traceback.format_exc()} if os.getenv('NODE_ENV') == 'development' else {})
        }
    )

