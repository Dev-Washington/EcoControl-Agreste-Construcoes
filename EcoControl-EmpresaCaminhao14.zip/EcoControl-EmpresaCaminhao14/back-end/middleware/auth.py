from functools import wraps
from typing import Optional, List
from fastapi import HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from datetime import datetime, timedelta
import os
from config.database import db

JWT_SECRET = os.getenv('JWT_SECRET', 'seu_secret_jwt_super_seguro_aqui')
JWT_EXPIRES_IN = os.getenv('JWT_EXPIRES_IN', '7d')
security = HTTPBearer()

def generate_token(user_id: str) -> str:
    """Gera um token JWT para o usuário"""
    expires_delta = timedelta(days=7)  # Default 7 dias
    if JWT_EXPIRES_IN.endswith('d'):
        days = int(JWT_EXPIRES_IN[:-1])
        expires_delta = timedelta(days=days)
    elif JWT_EXPIRES_IN.endswith('h'):
        hours = int(JWT_EXPIRES_IN[:-1])
        expires_delta = timedelta(hours=hours)
    
    expire = datetime.utcnow() + expires_delta
    
    payload = {
        'userId': user_id,
        'exp': expire
    }
    
    return jwt.encode(payload, JWT_SECRET, algorithm='HS256')

def verify_token(token: str) -> dict:
    """Verifica e decodifica um token JWT"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        return payload
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail='Token inválido ou expirado'
        )

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> dict:
    """Obtém o usuário atual a partir do token JWT"""
    token = credentials.credentials
    payload = verify_token(token)
    user_id = payload.get('userId')
    
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail='Token inválido'
        )
    
    # Buscar usuário no banco
    cursor = db.execute(
        'SELECT id, name, email, role, status FROM users WHERE id = ?',
        (user_id,)
    )
    user = cursor.fetchone()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail='Usuário não encontrado'
        )
    
    user_dict = dict(user)
    
    if user_dict['status'] != 'active':
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail='Usuário inativo'
        )
    
    return user_dict

def authorize(*roles: str):
    """Decorator para verificar roles do usuário"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            current_user = kwargs.get('current_user')
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail='Usuário não autenticado'
                )
            
            if current_user['role'] not in roles:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail='Acesso negado. Permissão insuficiente.'
                )
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator

