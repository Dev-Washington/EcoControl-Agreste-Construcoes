# Backend EcoControl - Sistema de Gestão de Frotas

Backend completo desenvolvido em Python/FastAPI para o sistema EcoControl da Agreste Construção.

## 🚀 Características

- **API RESTful** completa
- **Autenticação JWT** com roles e permissões
- **Banco de dados SQLite** (fácil migração para PostgreSQL/MySQL)
- **Validação de dados** com Pydantic
- **Estrutura modular** e escalável
- **CORS configurável**
- **Upload de arquivos** (imagens, documentos)
- **Documentação automática** com Swagger/OpenAPI

## 📋 Pré-requisitos

- Python 3.8+ instalado
- pip (gerenciador de pacotes Python)

## 🔧 Instalação

1. **Instalar dependências:**
```bash
cd back-end
pip install -r requirements.txt
```

2. **Configurar variáveis de ambiente:**
```bash
# Criar arquivo .env com as seguintes variáveis:
PORT=3000
JWT_SECRET=seu_secret_jwt_super_seguro_aqui
JWT_EXPIRES_IN=7d
CORS_ORIGIN=http://localhost:5500,http://127.0.0.1:5500
DB_PATH=./database/ecocontrol.db
UPLOAD_DIR=./uploads
MAX_FILE_SIZE=5242880
NODE_ENV=development
```

3. **Executar migrations:**
```bash
python migrations/create_tables.py
```

4. **Executar seed (criar usuário desenvolvedor padrão):**
```bash
python migrations/seed.py
```

5. **Iniciar servidor:**
```bash
# Desenvolvimento
python main.py

# Ou usando uvicorn diretamente
uvicorn main:app --reload --port 3000
```

O servidor estará rodando em `http://localhost:3000`

## 📡 Endpoints da API

### Autenticação
- `POST /api/auth/login` - Login
- `GET /api/auth/verify` - Verificar token

### Usuários
- `GET /api/users` - Listar usuários
- `GET /api/users/:id` - Obter usuário
- `POST /api/users` - Criar usuário (apenas gestores)
- `PUT /api/users/:id` - Atualizar usuário
- `DELETE /api/users/:id` - Deletar usuário (apenas gestores)

### Veículos/Caminhões
- `GET /api/vehicles` - Listar veículos
- `GET /api/vehicles/:id` - Obter veículo
- `POST /api/vehicles` - Criar veículo
- `PUT /api/vehicles/:id` - Atualizar veículo
- `DELETE /api/vehicles/:id` - Deletar veículo

### Clientes
- `GET /api/customers` - Listar clientes
- `GET /api/customers/:id` - Obter cliente
- `POST /api/customers` - Criar cliente
- `PUT /api/customers/:id` - Atualizar cliente
- `DELETE /api/customers/:id` - Deletar cliente

### Entregas
- `GET /api/deliveries` - Listar entregas
- `GET /api/deliveries/:id` - Obter entrega
- `POST /api/deliveries` - Criar entrega
- `PUT /api/deliveries/:id` - Atualizar entrega
- `DELETE /api/deliveries/:id` - Deletar entrega

### Rotas
- `GET /api/routes` - Listar rotas
- `GET /api/routes/:id` - Obter rota
- `POST /api/routes` - Criar rota
- `PUT /api/routes/:id` - Atualizar rota
- `DELETE /api/routes/:id` - Deletar rota

### Cidades
- `GET /api/cities` - Listar cidades
- `POST /api/cities` - Criar cidade

### Produtos
- `GET /api/products` - Listar produtos
- `POST /api/products` - Criar produto

### Manutenções
- `GET /api/maintenance` - Listar manutenções
- `POST /api/maintenance` - Criar manutenção
- `PUT /api/maintenance/:id` - Atualizar manutenção

### Mensagens/Chat
- `GET /api/messages/conversation/:userId` - Obter conversa
- `GET /api/messages/my-messages` - Minhas mensagens
- `POST /api/messages` - Enviar mensagem
- `PUT /api/messages/:id/read` - Marcar como lida
- `PUT /api/messages/conversation/:userId/read` - Marcar conversa como lida
- `DELETE /api/messages/conversation/:userId` - Deletar conversa

### Solicitações de Acesso
- `POST /api/access-requests` - Criar solicitação (público)
- `GET /api/access-requests` - Listar solicitações (apenas gestores)
- `PUT /api/access-requests/:id/approve` - Aprovar solicitação
- `PUT /api/access-requests/:id/reject` - Rejeitar solicitação

### Notificações
- `GET /api/notifications` - Listar notificações
- `PUT /api/notifications/:id/read` - Marcar como lida

### Relatórios
- `GET /api/reports/dashboard` - Relatório do dashboard

## 🔐 Autenticação

Todas as rotas (exceto `/api/auth/login` e `/api/access-requests` POST) requerem autenticação via JWT.

**Header necessário:**
```
Authorization: Bearer <token>
```

## 👤 Usuário Padrão

Após executar o seed, você terá um usuário desenvolvedor:
- **Email:** desenvolvedor@control.com
- **Senha:** admin123
- **Role:** gestor

## 📁 Estrutura do Projeto

```
back-end/
├── config/
│   ├── __init__.py
│   └── database.py          # Configuração do banco de dados
├── middleware/
│   ├── __init__.py
│   ├── auth.py              # Autenticação JWT
│   └── error_handler.py     # Tratamento de erros
├── migrations/
│   ├── __init__.py
│   ├── create_tables.py     # Criação das tabelas
│   └── seed.py              # Dados iniciais
├── models/
│   ├── __init__.py
│   ├── user.py              # Model de usuários
│   ├── vehicle.py           # Model de veículos
│   ├── customer.py          # Model de clientes
│   ├── delivery.py          # Model de entregas
│   ├── route.py             # Model de rotas
│   ├── message.py           # Model de mensagens
│   ├── maintenance.py       # Model de manutenções
│   └── access_request.py    # Model de solicitações
├── routes/
│   ├── __init__.py
│   ├── auth.py              # Rotas de autenticação
│   ├── users.py             # Rotas de usuários
│   ├── vehicles.py          # Rotas de veículos
│   ├── customers.py         # Rotas de clientes
│   ├── deliveries.py        # Rotas de entregas
│   ├── routes.py            # Rotas de rotas
│   ├── cities.py            # Rotas de cidades
│   ├── products.py          # Rotas de produtos
│   ├── maintenance.py       # Rotas de manutenções
│   ├── messages.py          # Rotas de mensagens
│   ├── access_requests.py  # Rotas de solicitações
│   ├── notifications.py    # Rotas de notificações
│   └── reports.py           # Rotas de relatórios
├── main.py                  # Servidor principal
├── requirements.txt         # Dependências Python
└── README.md                # Este arquivo
```

## 📚 Documentação da API

A documentação interativa da API está disponível em:
- **Swagger UI:** http://localhost:3000/docs
- **ReDoc:** http://localhost:3000/redoc
