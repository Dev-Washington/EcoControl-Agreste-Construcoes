import sqlite3
import os
from pathlib import Path
from typing import Optional

class Database:
    _instance: Optional['Database'] = None
    _connection: Optional[sqlite3.Connection] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._connection is None:
            db_path = os.getenv('DB_PATH', './database/ecocontrol.db')
            db_dir = Path(db_path).parent
            
            # Criar diretório se não existir
            db_dir.mkdir(parents=True, exist_ok=True)
            
            self._connection = sqlite3.connect(
                db_path,
                check_same_thread=False
            )
            self._connection.row_factory = sqlite3.Row
            
            # Habilitar foreign keys
            self._connection.execute('PRAGMA foreign_keys = ON')
            print('✅ Conectado ao banco de dados SQLite')
    
    @property
    def connection(self) -> sqlite3.Connection:
        return self._connection
    
    def execute(self, sql: str, params: tuple = ()):
        """Executa uma query e retorna o cursor"""
        return self._connection.execute(sql, params)
    
    def executemany(self, sql: str, params: list):
        """Executa uma query múltiplas vezes"""
        return self._connection.executemany(sql, params)
    
    def commit(self):
        """Commita as alterações"""
        self._connection.commit()
    
    def close(self):
        """Fecha a conexão"""
        if self._connection:
            self._connection.close()
            self._connection = None

# Instância global do banco de dados
db = Database()

