import uuid
import json
from datetime import datetime
from typing import Optional, Dict, Any
from config.database import db

class Delivery:
    @staticmethod
    def create(delivery_data: Dict[str, Any]) -> Dict[str, Any]:
        delivery_id = delivery_data.get('id') or f"DEL-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        tracking_code = delivery_data.get('trackingCode') or f"TRACK-{int(datetime.now().timestamp() * 1000)}"
        now = datetime.now().isoformat()
        
        items = delivery_data.get('items')
        if items and isinstance(items, (list, dict)):
            items = json.dumps(items)
        
        db.execute("""
            INSERT INTO deliveries (
                id, tracking_code, customer_id, customer_name, vehicle_id, driver_id, route_id,
                origin_city, origin_state, destination_city, destination_state, destination_address,
                scheduled_date, delivery_date, status, total_value, final_value, payment_method,
                payment_status, notes, items, created_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            delivery_id,
            tracking_code,
            delivery_data['customerId'],
            delivery_data['customerName'],
            delivery_data.get('vehicleId'),
            delivery_data.get('driverId'),
            delivery_data.get('routeId'),
            delivery_data['originCity'],
            delivery_data['originState'],
            delivery_data['destinationCity'],
            delivery_data['destinationState'],
            delivery_data.get('destinationAddress'),
            delivery_data.get('scheduledDate'),
            delivery_data.get('deliveryDate'),
            delivery_data.get('status', 'em_carregamento'),
            delivery_data.get('totalValue', 0),
            delivery_data.get('finalValue', 0),
            delivery_data.get('paymentMethod'),
            delivery_data.get('paymentStatus', 'pendente'),
            delivery_data.get('notes'),
            items,
            delivery_data.get('createdBy'),
            now,
            now
        ))
        db.commit()
        
        return Delivery.find_by_id(delivery_id)
    
    @staticmethod
    def find_by_id(delivery_id: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM deliveries WHERE id = ?', (delivery_id,))
        row = cursor.fetchone()
        if row:
            delivery = dict(row)
            if delivery.get('items'):
                try:
                    delivery['items'] = json.loads(delivery['items'])
                except:
                    pass
            return delivery
        return None
    
    @staticmethod
    def find_by_tracking_code(tracking_code: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM deliveries WHERE tracking_code = ?', (tracking_code,))
        row = cursor.fetchone()
        if row:
            delivery = dict(row)
            if delivery.get('items'):
                try:
                    delivery['items'] = json.loads(delivery['items'])
                except:
                    pass
            return delivery
        return None
    
    @staticmethod
    def find_all(filters: Optional[Dict[str, Any]] = None) -> list:
        if filters is None:
            filters = {}
        
        query = 'SELECT * FROM deliveries WHERE 1=1'
        params = []
        
        if filters.get('status'):
            query += ' AND status = ?'
            params.append(filters['status'])
        
        if filters.get('customerId'):
            query += ' AND customer_id = ?'
            params.append(filters['customerId'])
        
        if filters.get('driverId'):
            query += ' AND driver_id = ?'
            params.append(filters['driverId'])
        
        if filters.get('search'):
            query += ' AND (tracking_code LIKE ? OR customer_name LIKE ?)'
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term])
        
        if filters.get('dateStart'):
            query += ' AND scheduled_date >= ?'
            params.append(filters['dateStart'])
        
        if filters.get('dateEnd'):
            query += ' AND scheduled_date <= ?'
            params.append(filters['dateEnd'])
        
        query += ' ORDER BY created_at DESC'
        
        cursor = db.execute(query, tuple(params))
        rows = cursor.fetchall()
        
        deliveries = []
        for row in rows:
            delivery = dict(row)
            if delivery.get('items'):
                try:
                    delivery['items'] = json.loads(delivery['items'])
                except:
                    pass
            deliveries.append(delivery)
        
        return deliveries
    
    @staticmethod
    def update(delivery_id: str, delivery_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        now = datetime.now().isoformat()
        updates = []
        params = []
        
        items = delivery_data.get('items')
        if items and isinstance(items, (list, dict)):
            items = json.dumps(items)
        
        fields = {
            'tracking_code': delivery_data.get('trackingCode'),
            'customer_id': delivery_data.get('customerId'),
            'customer_name': delivery_data.get('customerName'),
            'vehicle_id': delivery_data.get('vehicleId'),
            'driver_id': delivery_data.get('driverId'),
            'route_id': delivery_data.get('routeId'),
            'origin_city': delivery_data.get('originCity'),
            'origin_state': delivery_data.get('originState'),
            'destination_city': delivery_data.get('destinationCity'),
            'destination_state': delivery_data.get('destinationState'),
            'destination_address': delivery_data.get('destinationAddress'),
            'scheduled_date': delivery_data.get('scheduledDate'),
            'delivery_date': delivery_data.get('deliveryDate'),
            'status': delivery_data.get('status'),
            'total_value': delivery_data.get('totalValue'),
            'final_value': delivery_data.get('finalValue'),
            'payment_method': delivery_data.get('paymentMethod'),
            'payment_status': delivery_data.get('paymentStatus'),
            'notes': delivery_data.get('notes'),
            'items': items
        }
        
        for key, value in fields.items():
            if value is not None:
                updates.append(f"{key} = ?")
                params.append(value)
        
        if not updates:
            return Delivery.find_by_id(delivery_id)
        
        updates.append('updated_at = ?')
        params.append(now)
        params.append(delivery_id)
        
        db.execute(
            f"UPDATE deliveries SET {', '.join(updates)} WHERE id = ?",
            tuple(params)
        )
        db.commit()
        
        return Delivery.find_by_id(delivery_id)
    
    @staticmethod
    def delete(delivery_id: str) -> bool:
        db.execute('DELETE FROM deliveries WHERE id = ?', (delivery_id,))
        db.commit()
        return True

# Alias para compatibilidade
Delivery.findById = Delivery.find_by_id

