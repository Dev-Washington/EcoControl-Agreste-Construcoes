import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from config.database import db

class Maintenance:
    @staticmethod
    def create(maintenance_data: Dict[str, Any]) -> Dict[str, Any]:
        maintenance_id = maintenance_data.get('id') or f"MAINT-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        db.execute("""
            INSERT INTO maintenance (
                id, vehicle_id, type, priority, description, date, cost, status,
                requested_by, automatic, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            maintenance_id,
            maintenance_data['vehicleId'],
            maintenance_data.get('type', 'preventiva'),
            maintenance_data.get('priority', 'normal'),
            maintenance_data['description'],
            maintenance_data['date'],
            maintenance_data.get('cost', 0),
            maintenance_data.get('status', 'pendente'),
            maintenance_data.get('requestedBy'),
            1 if maintenance_data.get('automatic') else 0,
            now,
            now
        ))
        db.commit()
        
        return Maintenance.find_by_id(maintenance_id)
    
    @staticmethod
    def find_by_id(maintenance_id: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM maintenance WHERE id = ?', (maintenance_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    
    @staticmethod
    def find_all(filters: Optional[Dict[str, Any]] = None) -> list:
        if filters is None:
            filters = {}
        
        query = 'SELECT * FROM maintenance WHERE 1=1'
        params = []
        
        if filters.get('vehicleId'):
            query += ' AND vehicle_id = ?'
            params.append(filters['vehicleId'])
        
        if filters.get('status'):
            query += ' AND status = ?'
            params.append(filters['status'])
        
        if filters.get('type'):
            query += ' AND type = ?'
            params.append(filters['type'])
        
        query += ' ORDER BY created_at DESC'
        
        cursor = db.execute(query, tuple(params))
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    
    @staticmethod
    def update(maintenance_id: str, maintenance_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        now = datetime.now().isoformat()
        updates = []
        params = []
        
        fields = {
            'vehicle_id': maintenance_data.get('vehicleId'),
            'type': maintenance_data.get('type'),
            'priority': maintenance_data.get('priority'),
            'description': maintenance_data.get('description'),
            'date': maintenance_data.get('date'),
            'cost': maintenance_data.get('cost'),
            'status': maintenance_data.get('status')
        }
        
        for key, value in fields.items():
            if value is not None:
                updates.append(f"{key} = ?")
                params.append(value)
        
        if not updates:
            return Maintenance.find_by_id(maintenance_id)
        
        updates.append('updated_at = ?')
        params.append(now)
        params.append(maintenance_id)
        
        db.execute(
            f"UPDATE maintenance SET {', '.join(updates)} WHERE id = ?",
            tuple(params)
        )
        db.commit()
        
        return Maintenance.find_by_id(maintenance_id)
    
    @staticmethod
    def delete(maintenance_id: str) -> bool:
        db.execute('DELETE FROM maintenance WHERE id = ?', (maintenance_id,))
        db.commit()
        return True

# Alias para compatibilidade
Maintenance.findById = Maintenance.find_by_id

