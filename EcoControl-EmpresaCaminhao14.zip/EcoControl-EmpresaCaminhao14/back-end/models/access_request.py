import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from config.database import db

class AccessRequest:
    @staticmethod
    def create(request_data: Dict[str, Any]) -> Dict[str, Any]:
        request_id = request_data.get('id') or f"REQ-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        db.execute("""
            INSERT INTO access_requests (
                id, full_name, email, phone, password, desired_role, system_type,
                reason, status, requested_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            request_id,
            request_data['fullName'],
            request_data['email'],
            request_data.get('phone'),
            request_data.get('password'),
            request_data['desiredRole'],
            request_data.get('systemType', 'dashboard'),
            request_data['reason'],
            request_data.get('status', 'pending'),
            request_data.get('requestedBy'),
            now,
            now
        ))
        db.commit()
        
        return AccessRequest.find_by_id(request_id)
    
    @staticmethod
    def find_by_id(request_id: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM access_requests WHERE id = ?', (request_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    
    @staticmethod
    def find_all(filters: Optional[Dict[str, Any]] = None) -> list:
        if filters is None:
            filters = {}
        
        query = 'SELECT * FROM access_requests WHERE 1=1'
        params = []
        
        if filters.get('status'):
            query += ' AND status = ?'
            params.append(filters['status'])
        
        if filters.get('email'):
            query += ' AND email = ?'
            params.append(filters['email'])
        
        query += ' ORDER BY created_at DESC'
        
        cursor = db.execute(query, tuple(params))
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    
    @staticmethod
    def update(request_id: str, request_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        now = datetime.now().isoformat()
        updates = []
        params = []
        
        fields = {
            'status': request_data.get('status'),
            'reviewed_by': request_data.get('reviewedBy'),
            'reviewed_at': request_data.get('reviewedAt')
        }
        
        for key, value in fields.items():
            if value is not None:
                updates.append(f"{key} = ?")
                params.append(value)
        
        if not updates:
            return AccessRequest.find_by_id(request_id)
        
        updates.append('updated_at = ?')
        params.append(now)
        params.append(request_id)
        
        db.execute(
            f"UPDATE access_requests SET {', '.join(updates)} WHERE id = ?",
            tuple(params)
        )
        db.commit()
        
        return AccessRequest.find_by_id(request_id)
    
    @staticmethod
    def delete(request_id: str) -> bool:
        db.execute('DELETE FROM access_requests WHERE id = ?', (request_id,))
        db.commit()
        return True

# Alias para compatibilidade
AccessRequest.findById = AccessRequest.find_by_id

