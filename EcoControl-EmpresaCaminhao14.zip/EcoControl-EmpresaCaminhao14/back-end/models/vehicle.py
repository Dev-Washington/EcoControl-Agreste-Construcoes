import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from config.database import db

class Vehicle:
    @staticmethod
    def create(vehicle_data: Dict[str, Any]) -> Dict[str, Any]:
        vehicle_id = vehicle_data.get('id') or f"TRUCK-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        db.execute("""
            INSERT INTO vehicles (
                id, plate, model, year, capacity, mileage, status, cargo_description,
                image, driver_id, route_id, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            vehicle_id,
            vehicle_data['plate'],
            vehicle_data['model'],
            vehicle_data.get('year'),
            vehicle_data.get('capacity'),
            vehicle_data.get('mileage', 0),
            vehicle_data.get('status', 'disponivel'),
            vehicle_data.get('cargoDescription'),
            vehicle_data.get('image'),
            vehicle_data.get('driverId'),
            vehicle_data.get('routeId'),
            now,
            now
        ))
        db.commit()
        
        return Vehicle.find_by_id(vehicle_id)
    
    @staticmethod
    def find_by_id(vehicle_id: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM vehicles WHERE id = ?', (vehicle_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    
    @staticmethod
    def find_all(filters: Optional[Dict[str, Any]] = None) -> list:
        if filters is None:
            filters = {}
        
        query = 'SELECT * FROM vehicles WHERE 1=1'
        params = []
        
        if filters.get('status'):
            query += ' AND status = ?'
            params.append(filters['status'])
        
        if filters.get('search'):
            query += ' AND (id LIKE ? OR plate LIKE ? OR model LIKE ?)'
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term, search_term])
        
        query += ' ORDER BY created_at DESC'
        
        cursor = db.execute(query, tuple(params))
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    
    @staticmethod
    def update(vehicle_id: str, vehicle_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        now = datetime.now().isoformat()
        updates = []
        params = []
        
        fields = {
            'plate': vehicle_data.get('plate'),
            'model': vehicle_data.get('model'),
            'year': vehicle_data.get('year'),
            'capacity': vehicle_data.get('capacity'),
            'mileage': vehicle_data.get('mileage'),
            'status': vehicle_data.get('status'),
            'cargo_description': vehicle_data.get('cargoDescription'),
            'image': vehicle_data.get('image'),
            'driver_id': vehicle_data.get('driverId'),
            'route_id': vehicle_data.get('routeId')
        }
        
        for key, value in fields.items():
            if value is not None:
                updates.append(f"{key} = ?")
                params.append(value)
        
        if not updates:
            return Vehicle.find_by_id(vehicle_id)
        
        updates.append('updated_at = ?')
        params.append(now)
        params.append(vehicle_id)
        
        db.execute(
            f"UPDATE vehicles SET {', '.join(updates)} WHERE id = ?",
            tuple(params)
        )
        db.commit()
        
        return Vehicle.find_by_id(vehicle_id)
    
    @staticmethod
    def delete(vehicle_id: str) -> bool:
        db.execute('DELETE FROM vehicles WHERE id = ?', (vehicle_id,))
        db.commit()
        return True

# Alias para compatibilidade
Vehicle.findById = Vehicle.find_by_id

