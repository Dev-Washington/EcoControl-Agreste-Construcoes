import uuid
import json
from datetime import datetime
from typing import Optional, Dict, Any
from config.database import db

class Route:
    @staticmethod
    def create(route_data: Dict[str, Any]) -> Dict[str, Any]:
        route_id = route_data.get('id') or f"ROUTE-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        assigned_drivers = route_data.get('assignedDrivers')
        if assigned_drivers and isinstance(assigned_drivers, (list, dict)):
            assigned_drivers = json.dumps(assigned_drivers)
        
        db.execute("""
            INSERT INTO routes (
                id, name, origin_street, origin_number, origin_complement, origin_neighborhood,
                origin_zip_code, origin_city, origin_state, destination_street, destination_number,
                destination_complement, destination_neighborhood, destination_zip_code,
                destination_city, destination_state, distance, estimated_time, status,
                assigned_drivers, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            route_id,
            route_data['name'],
            route_data.get('originStreet'),
            route_data.get('originNumber'),
            route_data.get('originComplement'),
            route_data.get('originNeighborhood'),
            route_data.get('originZipCode'),
            route_data['originCity'],
            route_data['originState'],
            route_data.get('destinationStreet'),
            route_data.get('destinationNumber'),
            route_data.get('destinationComplement'),
            route_data.get('destinationNeighborhood'),
            route_data.get('destinationZipCode'),
            route_data['destinationCity'],
            route_data['destinationState'],
            route_data.get('distance'),
            route_data.get('estimatedTime'),
            route_data.get('status', 'ativa'),
            assigned_drivers,
            now,
            now
        ))
        db.commit()
        
        return Route.find_by_id(route_id)
    
    @staticmethod
    def find_by_id(route_id: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM routes WHERE id = ?', (route_id,))
        row = cursor.fetchone()
        if row:
            route = dict(row)
            if route.get('assigned_drivers'):
                try:
                    route['assigned_drivers'] = json.loads(route['assigned_drivers'])
                except:
                    pass
            return route
        return None
    
    @staticmethod
    def find_all(filters: Optional[Dict[str, Any]] = None) -> list:
        if filters is None:
            filters = {}
        
        query = 'SELECT * FROM routes WHERE 1=1'
        params = []
        
        if filters.get('status'):
            query += ' AND status = ?'
            params.append(filters['status'])
        
        if filters.get('search'):
            query += ' AND (name LIKE ? OR origin_city LIKE ? OR destination_city LIKE ?)'
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term, search_term])
        
        query += ' ORDER BY created_at DESC'
        
        cursor = db.execute(query, tuple(params))
        rows = cursor.fetchall()
        
        routes = []
        for row in rows:
            route = dict(row)
            if route.get('assigned_drivers'):
                try:
                    route['assigned_drivers'] = json.loads(route['assigned_drivers'])
                except:
                    pass
            routes.append(route)
        
        return routes
    
    @staticmethod
    def update(route_id: str, route_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        now = datetime.now().isoformat()
        updates = []
        params = []
        
        assigned_drivers = route_data.get('assignedDrivers')
        if assigned_drivers and isinstance(assigned_drivers, (list, dict)):
            assigned_drivers = json.dumps(assigned_drivers)
        
        fields = {
            'name': route_data.get('name'),
            'origin_street': route_data.get('originStreet'),
            'origin_number': route_data.get('originNumber'),
            'origin_complement': route_data.get('originComplement'),
            'origin_neighborhood': route_data.get('originNeighborhood'),
            'origin_zip_code': route_data.get('originZipCode'),
            'origin_city': route_data.get('originCity'),
            'origin_state': route_data.get('originState'),
            'destination_street': route_data.get('destinationStreet'),
            'destination_number': route_data.get('destinationNumber'),
            'destination_complement': route_data.get('destinationComplement'),
            'destination_neighborhood': route_data.get('destinationNeighborhood'),
            'destination_zip_code': route_data.get('destinationZipCode'),
            'destination_city': route_data.get('destinationCity'),
            'destination_state': route_data.get('destinationState'),
            'distance': route_data.get('distance'),
            'estimated_time': route_data.get('estimatedTime'),
            'status': route_data.get('status'),
            'assigned_drivers': assigned_drivers
        }
        
        for key, value in fields.items():
            if value is not None:
                updates.append(f"{key} = ?")
                params.append(value)
        
        if not updates:
            return Route.find_by_id(route_id)
        
        updates.append('updated_at = ?')
        params.append(now)
        params.append(route_id)
        
        db.execute(
            f"UPDATE routes SET {', '.join(updates)} WHERE id = ?",
            tuple(params)
        )
        db.commit()
        
        return Route.find_by_id(route_id)
    
    @staticmethod
    def delete(route_id: str) -> bool:
        db.execute('DELETE FROM routes WHERE id = ?', (route_id,))
        db.commit()
        return True

# Alias para compatibilidade
Route.findById = Route.find_by_id

