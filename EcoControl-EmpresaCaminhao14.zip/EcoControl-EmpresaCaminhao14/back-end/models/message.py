import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from config.database import db

class Message:
    @staticmethod
    def create(message_data: Dict[str, Any]) -> Dict[str, Any]:
        message_id = message_data.get('id') or f"MSG-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        db.execute("""
            INSERT INTO messages (
                id, from_user_id, from_user_name, to_user_id, to_user_name, subject,
                content, image, priority, read, delivery_id, vehicle_id, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            message_id,
            message_data['fromUserId'],
            message_data['fromUserName'],
            message_data.get('toUserId'),
            message_data.get('toUserName'),
            message_data.get('subject'),
            message_data.get('content'),
            message_data.get('image'),
            message_data.get('priority', 'normal'),
            1 if message_data.get('read') else 0,
            message_data.get('deliveryId'),
            message_data.get('vehicleId'),
            now
        ))
        db.commit()
        
        return Message.find_by_id(message_id)
    
    @staticmethod
    def find_by_id(message_id: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM messages WHERE id = ?', (message_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    
    @staticmethod
    def find_conversation(user_id1: str, user_id2: str) -> list:
        cursor = db.execute("""
            SELECT * FROM messages 
            WHERE (from_user_id = ? AND to_user_id = ?) 
               OR (from_user_id = ? AND to_user_id = ?)
            ORDER BY created_at ASC
        """, (user_id1, user_id2, user_id2, user_id1))
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    
    @staticmethod
    def find_user_messages(user_id: str) -> list:
        cursor = db.execute("""
            SELECT * FROM messages 
            WHERE from_user_id = ? OR to_user_id = ?
            ORDER BY created_at DESC
        """, (user_id, user_id))
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    
    @staticmethod
    def mark_as_read(message_id: str) -> Optional[Dict[str, Any]]:
        db.execute('UPDATE messages SET read = 1 WHERE id = ?', (message_id,))
        db.commit()
        return Message.find_by_id(message_id)
    
    @staticmethod
    def mark_conversation_as_read(user_id1: str, user_id2: str) -> bool:
        db.execute("""
            UPDATE messages 
            SET read = 1 
            WHERE from_user_id = ? AND to_user_id = ? AND read = 0
        """, (user_id2, user_id1))
        db.commit()
        return True
    
    @staticmethod
    def delete(message_id: str) -> bool:
        db.execute('DELETE FROM messages WHERE id = ?', (message_id,))
        db.commit()
        return True
    
    @staticmethod
    def delete_conversation(user_id1: str, user_id2: str) -> bool:
        db.execute("""
            DELETE FROM messages 
            WHERE (from_user_id = ? AND to_user_id = ?) 
               OR (from_user_id = ? AND to_user_id = ?)
        """, (user_id1, user_id2, user_id2, user_id1))
        db.commit()
        return True

# Alias para compatibilidade
Message.findById = Message.find_by_id

