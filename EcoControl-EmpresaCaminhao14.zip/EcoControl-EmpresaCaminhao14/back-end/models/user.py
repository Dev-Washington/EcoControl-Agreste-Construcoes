import uuid
import json
from datetime import datetime
from typing import Optional, Dict, Any
from config.database import db

class User:
    @staticmethod
    def create(user_data: Dict[str, Any]) -> Dict[str, Any]:
        user_id = user_data.get('id') or f"USER-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        work_schedule = user_data.get('workSchedule')
        if work_schedule and isinstance(work_schedule, dict):
            work_schedule = json.dumps(work_schedule)
        
        db.execute("""
            INSERT INTO users (
                id, name, email, password, role, phone, cpf, birth_date, hire_date,
                address, address_street, address_number, address_complement,
                address_neighborhood, address_zip_code, address_city, address_state,
                photo, status, work_schedule, system_type, company, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            user_data['name'],
            user_data['email'],
            user_data['password'],
            user_data.get('role', 'funcionario'),
            user_data.get('phone'),
            user_data.get('cpf'),
            user_data.get('birthDate'),
            user_data.get('hireDate'),
            user_data.get('address'),
            user_data.get('addressStreet'),
            user_data.get('addressNumber'),
            user_data.get('addressComplement'),
            user_data.get('addressNeighborhood'),
            user_data.get('addressZipCode'),
            user_data.get('addressCity'),
            user_data.get('addressState'),
            user_data.get('photo'),
            user_data.get('status', 'active'),
            work_schedule,
            user_data.get('systemType', 'dashboard'),
            user_data.get('company'),
            now,
            now
        ))
        db.commit()
        
        return User.findById(user_id)
    
    @staticmethod
    def find_by_id(user_id: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        row = cursor.fetchone()
        if row:
            user = dict(row)
            if user.get('work_schedule'):
                try:
                    user['work_schedule'] = json.loads(user['work_schedule'])
                except:
                    pass
            return user
        return None
    
    @staticmethod
    def find_by_email(email: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM users WHERE email = ?', (email,))
        row = cursor.fetchone()
        if row:
            user = dict(row)
            if user.get('work_schedule'):
                try:
                    user['work_schedule'] = json.loads(user['work_schedule'])
                except:
                    pass
            return user
        return None
    
    @staticmethod
    def find_all(filters: Optional[Dict[str, Any]] = None) -> list:
        if filters is None:
            filters = {}
        
        query = 'SELECT * FROM users WHERE 1=1'
        params = []
        
        if filters.get('role'):
            query += ' AND role = ?'
            params.append(filters['role'])
        
        if filters.get('status'):
            query += ' AND status = ?'
            params.append(filters['status'])
        
        if filters.get('search'):
            query += ' AND (name LIKE ? OR email LIKE ?)'
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term])
        
        query += ' ORDER BY created_at DESC'
        
        cursor = db.execute(query, tuple(params))
        rows = cursor.fetchall()
        
        users = []
        for row in rows:
            user = dict(row)
            if user.get('work_schedule'):
                try:
                    user['work_schedule'] = json.loads(user['work_schedule'])
                except:
                    pass
            users.append(user)
        
        return users
    
    @staticmethod
    def update(user_id: str, user_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        now = datetime.now().isoformat()
        updates = []
        params = []
        
        fields = {
            'name': user_data.get('name'),
            'email': user_data.get('email'),
            'password': user_data.get('password'),
            'role': user_data.get('role'),
            'phone': user_data.get('phone'),
            'cpf': user_data.get('cpf'),
            'birth_date': user_data.get('birthDate'),
            'hire_date': user_data.get('hireDate'),
            'address': user_data.get('address'),
            'address_street': user_data.get('addressStreet'),
            'address_number': user_data.get('addressNumber'),
            'address_complement': user_data.get('addressComplement'),
            'address_neighborhood': user_data.get('addressNeighborhood'),
            'address_zip_code': user_data.get('addressZipCode'),
            'address_city': user_data.get('addressCity'),
            'address_state': user_data.get('addressState'),
            'photo': user_data.get('photo'),
            'status': user_data.get('status'),
            'current_truck_id': user_data.get('currentTruckId'),
            'current_route_id': user_data.get('currentRouteId')
        }
        
        if user_data.get('workSchedule'):
            fields['work_schedule'] = json.dumps(user_data['workSchedule']) if isinstance(user_data['workSchedule'], dict) else user_data['workSchedule']
        else:
            fields['work_schedule'] = None
        
        for key, value in fields.items():
            if value is not None:
                updates.append(f"{key} = ?")
                params.append(value)
        
        if not updates:
            return User.find_by_id(user_id)
        
        updates.append('updated_at = ?')
        params.append(now)
        params.append(user_id)
        
        db.execute(
            f"UPDATE users SET {', '.join(updates)} WHERE id = ?",
            tuple(params)
        )
        db.commit()
        
        return User.find_by_id(user_id)
    
    @staticmethod
    def delete(user_id: str) -> bool:
        db.execute('DELETE FROM users WHERE id = ?', (user_id,))
        db.commit()
        return True

# Alias para compatibilidade
User.findById = User.find_by_id

