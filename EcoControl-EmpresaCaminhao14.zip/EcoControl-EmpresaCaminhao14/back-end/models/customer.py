import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from config.database import db

class Customer:
    @staticmethod
    def create(customer_data: Dict[str, Any]) -> Dict[str, Any]:
        customer_id = customer_data.get('id') or f"CUST-{int(datetime.now().timestamp() * 1000)}-{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()
        
        db.execute("""
            INSERT INTO customers (
                id, name, name_fantasy, document, state_registration, type, birth_date,
                email, phone, cellphone, contact_person, address_street, address_number,
                address_complement, address_neighborhood, address_zip_code, address_city,
                address_state, status, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            customer_id,
            customer_data['name'],
            customer_data.get('nameFantasy'),
            customer_data['document'],
            customer_data.get('stateRegistration'),
            customer_data.get('type', 'pf'),
            customer_data.get('birthDate'),
            customer_data['email'],
            customer_data.get('phone'),
            customer_data.get('cellphone'),
            customer_data.get('contactPerson'),
            customer_data['addressStreet'],
            customer_data.get('addressNumber'),
            customer_data.get('addressComplement'),
            customer_data['addressNeighborhood'],
            customer_data['addressZipCode'],
            customer_data['addressCity'],
            customer_data['addressState'],
            customer_data.get('status', 'ativo'),
            customer_data.get('notes'),
            now,
            now
        ))
        db.commit()
        
        return Customer.find_by_id(customer_id)
    
    @staticmethod
    def find_by_id(customer_id: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM customers WHERE id = ?', (customer_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    
    @staticmethod
    def find_by_document(document: str) -> Optional[Dict[str, Any]]:
        cursor = db.execute('SELECT * FROM customers WHERE document = ?', (document,))
        row = cursor.fetchone()
        return dict(row) if row else None
    
    @staticmethod
    def find_all(filters: Optional[Dict[str, Any]] = None) -> list:
        if filters is None:
            filters = {}
        
        query = 'SELECT * FROM customers WHERE 1=1'
        params = []
        
        if filters.get('status'):
            query += ' AND status = ?'
            params.append(filters['status'])
        
        if filters.get('type'):
            query += ' AND type = ?'
            params.append(filters['type'])
        
        if filters.get('search'):
            query += ' AND (id LIKE ? OR name LIKE ? OR document LIKE ? OR email LIKE ?)'
            search_term = f"%{filters['search']}%"
            params.extend([search_term, search_term, search_term, search_term])
        
        query += ' ORDER BY created_at DESC'
        
        cursor = db.execute(query, tuple(params))
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
    
    @staticmethod
    def update(customer_id: str, customer_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        now = datetime.now().isoformat()
        updates = []
        params = []
        
        fields = {
            'name': customer_data.get('name'),
            'name_fantasy': customer_data.get('nameFantasy'),
            'document': customer_data.get('document'),
            'state_registration': customer_data.get('stateRegistration'),
            'type': customer_data.get('type'),
            'birth_date': customer_data.get('birthDate'),
            'email': customer_data.get('email'),
            'phone': customer_data.get('phone'),
            'cellphone': customer_data.get('cellphone'),
            'contact_person': customer_data.get('contactPerson'),
            'address_street': customer_data.get('addressStreet'),
            'address_number': customer_data.get('addressNumber'),
            'address_complement': customer_data.get('addressComplement'),
            'address_neighborhood': customer_data.get('addressNeighborhood'),
            'address_zip_code': customer_data.get('addressZipCode'),
            'address_city': customer_data.get('addressCity'),
            'address_state': customer_data.get('addressState'),
            'status': customer_data.get('status'),
            'notes': customer_data.get('notes')
        }
        
        for key, value in fields.items():
            if value is not None:
                updates.append(f"{key} = ?")
                params.append(value)
        
        if not updates:
            return Customer.find_by_id(customer_id)
        
        updates.append('updated_at = ?')
        params.append(now)
        params.append(customer_id)
        
        db.execute(
            f"UPDATE customers SET {', '.join(updates)} WHERE id = ?",
            tuple(params)
        )
        db.commit()
        
        return Customer.find_by_id(customer_id)
    
    @staticmethod
    def delete(customer_id: str) -> bool:
        db.execute('DELETE FROM customers WHERE id = ?', (customer_id,))
        db.commit()
        return True

# Alias para compatibilidade
Customer.findById = Customer.find_by_id

